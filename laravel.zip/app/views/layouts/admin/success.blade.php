@extends('layouts.master')

@section('content')
    <!-- content row -->
    <div class="row content-holder login-area">
        <div class="col-md-6 col-md-offset-3">
            <div class="btn btn-success">{{$message}}</div>
        </div>
    </div>
    <!-- end of content row -->
@stop